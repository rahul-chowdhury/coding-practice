from distutils.core import setup
setup(
	name="star_wars",
	version='1.0.0',
	py_modules=['star_wars'],
	author="rahul",
	author_email="rahul101chowdhury@gmail.com",
	description="a test module for decryption"
	)
